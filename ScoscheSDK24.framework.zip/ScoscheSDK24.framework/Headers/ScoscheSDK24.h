//
//  ScoscheSDK24.h
//  ScoscheSDK24
//
//  Created by Steffin Fox Griswold on 11/20/20.
//  Copyright © 2020 NPE INC. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ScoscheSDK24.
FOUNDATION_EXPORT double ScoscheSDK24VersionNumber;

//! Project version string for ScoscheSDK24.
FOUNDATION_EXPORT const unsigned char ScoscheSDK24VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ScoscheSDK24/PublicHeader.h>


